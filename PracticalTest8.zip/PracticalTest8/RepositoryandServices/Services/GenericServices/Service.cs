﻿using OA_Domain;
using RepositoryandServices.Repository.Generic_Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryandServices.Services.GenericServices
{
    public class Service<T> : IService<T> where T : BaseEntity
    {
        private readonly IRepository<T> repository;

        public Service(IRepository<T> repository)
        {
            this.repository = repository;
        }

        public Task<bool> DeleteAsync(T entity)
        {
            return repository.DeleteAsync(entity);
        }

        public Task<T> FindAsync(Expression<Func<T, bool>> match)
        {
            return repository.FindAsync(match);
        }

        public Task<ICollection<T>> GetAllAsync()
        {
            return repository.GetAllAsync();
        }

        public Task<T> GetByIDAsync(int Id)
        {
            return repository.GetByIDAsync(Id);
        }

        public Task<bool> InsertAsync(T entity)
        {
            return repository.InsertAsync(entity);
        }

        public Task<bool> UpdateAsync(T entity)
        {
            return repository.UpdateAsync(entity);
        }
    }
}
