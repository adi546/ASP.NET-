﻿using OA_Domain.Models;
using OA_Domain.ViewModels;
using RepositoryandServices.Repository.Custom_Repository;
using RepositoryandServices.Repository.Generic_Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using static OA_Domain.ViewModels.StudentViewModel;

namespace RepositoryandServices.Services.CustomServices.StudentService
{
    public class StudentService : IStudentService
    {
        private readonly IRepository<Student> repository;
        private readonly IStudentRepository studentRepository;

        public StudentService(IRepository<Student> repository, IStudentRepository studentRepository)
        {
            this.repository = repository;
            this.studentRepository = studentRepository;
        }

        public async Task<bool> DeleteAsync(int Id)
        {
            var deleteuser = await repository.GetByIDAsync(Id);
            if (deleteuser != null)
            {
                await repository.DeleteAsync(deleteuser);
                return true;
            }
            return false;
        }

        public async Task<Student> FindAsync(Expression<Func<Student, bool>> match)
        {
            return await repository.FindAsync(match);
        }

        public async Task<ICollection<StudentViewModel>> GetAllAsync()
        {
            var getall = await repository.GetAllAsync();

            return getall.Select(x => new StudentViewModel
            {
               StudentId = x.Id,
               Name = x.Name,
               Email = x.Email,
               PhoneNumber = x.PhoneNumber,
               Gender = x.Gender,
               DateOfBirth = x.DateOfBirth,
               CourseId = x.CourseId


            }).ToList();
        }

        public async Task<StudentViewModel> GetByIDAsync(int Id)
        {
            var getid = await repository.GetByIDAsync(Id);
            if (getid == null)
            {
                return null;
            }

            return new StudentViewModel
            {
                StudentId = getid.Id,
                Name = getid.Name,
                Email = getid.Email,
                PhoneNumber = getid.PhoneNumber,
                Gender = getid.Gender,
                DateOfBirth = getid.DateOfBirth,
                CourseId = getid.CourseId,

            };
        }

        public async Task<IEnumerable<Student>> GetStudentsByCourseNameAsync(string courseName)
        {
            return await studentRepository.GetStudentsByCourseNameAsync(courseName);
        }

        public async Task<bool> InsertAsync(StudentInsertModel studentInsertModel)
        {
            if (studentInsertModel == null)
            {
                return false;
            }
            else
            {
                Student student = new()
                {
                    Name = studentInsertModel.Name,
                    Email = studentInsertModel.Email,
                    PhoneNumber = studentInsertModel.PhoneNumber,
                    Gender = studentInsertModel.Gender,
                    DateOfBirth = studentInsertModel.DateOfBirth,
                    CourseId =studentInsertModel.CourseId,
                   


                };
                return await repository.InsertAsync(student);
            }
        }

        public async Task<bool> UpdateAsync(StudentUpdateModel studentUpdateModel)
        {
            var studentupdate = await repository.GetByIDAsync(studentUpdateModel.StudentId);
            if (studentupdate != null)
            {
                studentupdate.Id = studentUpdateModel.StudentId;
                studentupdate.Name = studentUpdateModel.Name;
                studentupdate.Email = studentUpdateModel.Email;
                studentupdate.PhoneNumber = studentUpdateModel.PhoneNumber;
                studentupdate.Gender = studentUpdateModel.Gender;
                studentupdate.DateOfBirth = studentUpdateModel.DateOfBirth;
                studentupdate.CourseId = studentUpdateModel.CourseId;


                return await repository.UpdateAsync(studentupdate);
            }
            else
            {
                return false;
            }
        }
    }
}
