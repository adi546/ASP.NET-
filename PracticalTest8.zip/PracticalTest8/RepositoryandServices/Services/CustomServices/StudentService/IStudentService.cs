﻿using OA_Domain.Models;
using OA_Domain.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using static OA_Domain.ViewModels.StudentViewModel;

namespace RepositoryandServices.Services.CustomServices.StudentService
{
    public interface IStudentService
    {
        Task<ICollection<StudentViewModel>> GetAllAsync();

        Task<StudentViewModel> GetByIDAsync(int Id);

        Task<bool> InsertAsync(StudentInsertModel studentInsertModel);

        Task<bool> UpdateAsync(StudentUpdateModel studentUpdateModel);

        Task<bool> DeleteAsync(int Id);

        Task<Student> FindAsync(Expression<Func<Student, bool>> match);

        Task<IEnumerable<Student>> GetStudentsByCourseNameAsync(string courseName);

    }
}
