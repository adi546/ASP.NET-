﻿using OA_Domain.Models;
using OA_Domain.ViewModels;
using RepositoryandServices.Repository.Custom_Repository;
using RepositoryandServices.Repository.Generic_Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using static OA_Domain.ViewModels.CourseViewModel;

namespace RepositoryandServices.Services.CustomServices.CourseService
{
    public class CourseService : ICourseService
    {
        private readonly IRepository<Course> repository;
        private readonly ICourseRepository courseRepository;

        public CourseService(IRepository<Course> repository, ICourseRepository courseRepository)
        {
            this.repository = repository;
            this.courseRepository = courseRepository;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var deleteuser = await repository.GetByIDAsync(id);
            if (deleteuser != null)
            {
                await repository.DeleteAsync(deleteuser);
                return true;
            }
            return false;
        }

        public async Task<Course> FindAsync(Expression<Func<Course, bool>> match)
        {
            return await repository.FindAsync(match);
        }

        public async Task<ICollection<CourseViewModel>> GetAllAsync()
        {
            var getall = await repository.GetAllAsync();

            return getall.Select(x => new CourseViewModel
            {
                CourseId = x.Id,
                CourseName = x.CourseName
            }).ToList();
        }

        public async Task<CourseViewModel> GetByIDAsync(int Id)
        {
            var getid = await repository.GetByIDAsync(Id);
            if (getid == null)
            {
                return null;
            }

            return new CourseViewModel
            {
                CourseId = getid.Id,
                CourseName = getid.CourseName


            };
        }

        public async Task<int> GetMonthlyFeesByCourseAsync(int courseId, int year)
        {
           return await courseRepository.GetMonthlyFeesByCourseAsync(courseId, year);
        }

        public async Task<bool> InsertAsync(CourseInsertModel courseInsertModel)
        {
            if (courseInsertModel == null)
            {
                return false;
            }
            else
            {
                Course course = new()
                {

                  CourseName = courseInsertModel.CourseName



                };
                return await repository.InsertAsync(course);
            }
        }

        public async Task<bool> UpdateAsync(CourseUpdateModel courseUpdateModel)
        {
            var courseupdate = await repository.GetByIDAsync(courseUpdateModel.CourseId);
            if (courseupdate != null)
            {
                courseupdate.Id = courseUpdateModel.CourseId;
                courseupdate.CourseName = courseUpdateModel.CourseName;



                return await repository.UpdateAsync(courseupdate);
            }
            else
            {
                return false;
            }
        }
    }
}
