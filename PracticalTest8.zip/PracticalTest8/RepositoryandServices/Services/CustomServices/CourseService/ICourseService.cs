﻿using OA_Domain.Models;
using OA_Domain.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using static OA_Domain.ViewModels.CourseViewModel;

namespace RepositoryandServices.Services.CustomServices.CourseService
{
    public interface ICourseService
    {
        Task<ICollection<CourseViewModel>> GetAllAsync();

        Task<CourseViewModel> GetByIDAsync(int Id);

        Task<bool> InsertAsync(CourseInsertModel courseInsertModel);

        Task<bool> UpdateAsync(CourseUpdateModel courseUpdateModel);

        Task<bool> DeleteAsync(int id);

        Task<Course> FindAsync(Expression<Func<Course, bool>> match);

        Task<int> GetMonthlyFeesByCourseAsync(int courseId, int year);
    }
}
