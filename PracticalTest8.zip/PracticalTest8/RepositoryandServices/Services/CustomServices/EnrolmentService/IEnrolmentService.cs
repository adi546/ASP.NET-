﻿using OA_Domain.Models;
using OA_Domain.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using static OA_Domain.ViewModels.EnrolmentViewModel;

namespace RepositoryandServices.Services.CustomServices.EnrolmentService
{
    public interface IEnrolmentService
    {
        Task<ICollection<EnrolmentViewModel>> GetAllAsync();

        Task<EnrolmentViewModel> GetByIDAsync(int Id);

        Task<bool> InsertAsync(EnrolmentInsertModel enrolmentInsertModel);

        Task<bool> UpdateAsync(EnrolmentUpdateModel enrolmentUpdateModel);

        Task<bool> DeleteAsync(int Id);

        Task<Enrolment> FindAsync(Expression<Func<Enrolment, bool>> match);
    }
}
