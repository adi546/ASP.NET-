﻿using OA_Domain.Models;
using OA_Domain.ViewModels;
using RepositoryandServices.Repository.Generic_Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using static OA_Domain.ViewModels.EnrolmentViewModel;

namespace RepositoryandServices.Services.CustomServices.EnrolmentService
{
    public class EnrolmentService : IEnrolmentService
    {
        private readonly IRepository<Enrolment> repository;

        public EnrolmentService(IRepository<Enrolment> repository)
        {
            this.repository = repository;
        }

        public async Task<bool> DeleteAsync(int Id)
        {
            var deleteuser = await repository.GetByIDAsync(Id);
            if (deleteuser != null)
            {
                await repository.DeleteAsync(deleteuser);
                return true;
            }
            return false;
        }

        public async Task<Enrolment> FindAsync(Expression<Func<Enrolment, bool>> match)
        {
            return await repository.FindAsync(match);
        }

        public async Task<ICollection<EnrolmentViewModel>> GetAllAsync()
        {
            var getall = await repository.GetAllAsync();

            return getall.Select(x => new EnrolmentViewModel
            {
                EnrolmentId = x.Id,
                StudentId = x.StudentId,
                CourseId = x.CourseId,
                Date = x.Date,
                Fees = x.Fees


            }).ToList();
        }

        public async Task<EnrolmentViewModel> GetByIDAsync(int Id)
        {
            var getid = await repository.GetByIDAsync(Id);
            if (getid == null)
            {
                return null;
            }

            return new EnrolmentViewModel
            {
                EnrolmentId = getid.Id,
                StudentId = getid.StudentId,
                CourseId = getid.CourseId,
                Date =getid.Date,
                Fees = getid.Fees

            };
        }

        public async Task<bool> InsertAsync(EnrolmentInsertModel enrolmentInsertModel)
        {
            if (enrolmentInsertModel == null)
            {
                return false;
            }
            else
            {
                Enrolment enrolment = new()
                {
                    StudentId = enrolmentInsertModel.StudentId,
                    CourseId = enrolmentInsertModel.CourseId,
                    Date = enrolmentInsertModel.Date,
                    Fees= enrolmentInsertModel.Fees
                  



                };
                return await repository.InsertAsync(enrolment);
            }
        }

        public async Task<bool> UpdateAsync(EnrolmentUpdateModel enrolmentUpdateModel)
        {
            var enrolmentupdate = await repository.GetByIDAsync(enrolmentUpdateModel.EnrolmentId);
            if (enrolmentupdate != null)
            {
                enrolmentupdate.Id = enrolmentUpdateModel.EnrolmentId;
                enrolmentupdate.StudentId = enrolmentUpdateModel.StudentId;
                enrolmentupdate.CourseId = enrolmentUpdateModel.CourseId;
                enrolmentupdate.Date = enrolmentUpdateModel.Date;
                enrolmentupdate.Fees = enrolmentUpdateModel.Fees;

                return await repository.UpdateAsync(enrolmentupdate);
            }
            else
            {
                return false;
            }
        }
    }
}
