﻿using Microsoft.EntityFrameworkCore;
using OA_Domain.Models;
using RepositoryandServices.Context;
using RepositoryandServices.Repository.Generic_Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryandServices.Repository.Custom_Repository
{
    public class CourseRepository : Repository<Course> , ICourseRepository
    {
        public CourseRepository(ApplicationDbContext context) : base(context) 
        {
            
        }

        public async Task<int> GetMonthlyFeesByCourseAsync(int courseId, int year)
        {
            var enrolments = await context.Enrolments
                .Where(e => e.CourseId == courseId && e.Date.Year == year)
                .GroupBy(e => e.Date.Month)
                .Select(g => new
                {
                    Month = g.Key,
                    TotalFees = g.Sum(e => e.Fees)
                })
            .ToListAsync();

            return enrolments.Sum(e => e.TotalFees);
        }
    }
}
