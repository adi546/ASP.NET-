﻿using OA_Domain.Helper;
using System.Text.Json;

namespace OA_WebAPI.Middleware
{
    public class RequestLoggingMiddleware
    {
        #region Private Variables
        private readonly ILogger _logger;
        private readonly RequestDelegate _next;
        #endregion

        #region Constructor
        public RequestLoggingMiddleware(ILoggerFactory loggerFactory, RequestDelegate next)
        {
            _logger = loggerFactory.CreateLogger<RequestLoggingMiddleware>();
            _next = next;
        }
        #endregion

        #region Function to Invoke on Request
        public async Task Invoke(HttpContext context)
        {
            await _next(context);

            if (context.Response.StatusCode == StatusCodes.Status405MethodNotAllowed)
            {
                context.Response.ContentType = "application/json";

                var responseMessage = new Response("Error", "You are not authorized to access this resource.");
                var jsonResponse = JsonSerializer.Serialize(responseMessage);

                await context.Response.WriteAsync(jsonResponse);
            }
        }
        #endregion
    }
}
