﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RepositoryandServices.Services.CustomServices.StudentService;
using static OA_Domain.ViewModels.StudentViewModel;

namespace OA_WebAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentService studentService;
        private readonly ILogger<StudentController> logger;

        public StudentController(IStudentService studentService, ILogger<StudentController> logger)
        {
            this.studentService = studentService;
            this.logger = logger;
        }

        [HttpGet("GetAllStudentDetails")]

        public async Task<IActionResult> GetAllStudentDetails()
        {
            var details = await studentService.GetAllAsync();

            if (details != null)
            {
                logger.LogInformation("Successfully Retrieved the details");
                return Ok(details);
            }
            logger.LogWarning("Unable to retrieve details");
            return BadRequest("Details not found");
        }

        [HttpGet("GetStudentDetailsById")]

        public async Task<IActionResult> GetStudentDetailsById(int Id)
        {
            var detailsbyid = await studentService.GetByIDAsync(Id);
            if (detailsbyid != null)
            {
                logger.LogInformation("Successfully Retrieved the details");
                return Ok(detailsbyid);
            }
            logger.LogWarning("Unable to retrieve details");
            return BadRequest("Details not found");
        }

        [HttpPost("AddStudentDetails")]

        public async Task<IActionResult> AddStudentDetails([FromBody] StudentInsertModel studentInsertModel)
        {
            if (ModelState.IsValid)
            {
               var insert = await studentService.InsertAsync(studentInsertModel);

                if(insert)
                {
                    logger.LogInformation("Successfully Inserted");
                    return Ok("Details Inserted Successfully");
                }
                else
                {
                    logger.LogWarning("Unable to insert");
                    return BadRequest("Failed to insert the details");
                }

            }
            return BadRequest("Invalid model state.");
        }

        [HttpPut("UpdateStudentDetails")]

        public async Task<IActionResult> UpdateStudentDetails([FromBody] StudentUpdateModel studentUpdateModel)
        {
            if (ModelState.IsValid)
            {
                var updatestudents = await studentService.GetByIDAsync(studentUpdateModel.StudentId);

                if(updatestudents != null)
                {
                    var update = await studentService.UpdateAsync(studentUpdateModel);

                    if(update)
                    {
                        logger.LogInformation("Details Updated Successfully");
                        return Ok("Details Updated Successfully");
                    }
                    else
                    {
                        logger.LogWarning("Unable to update");
                        return BadRequest("Failed to update details");
                    }

                }

                logger.LogWarning("No Id found");
                return BadRequest("Id does not exist");

                
            }
            logger.LogWarning("Invalid State");
            return BadRequest("Invalid Model State");


        }

        [HttpDelete("DeleteStudentDetails")]

        public async Task<IActionResult> DeleteStudentDetails(int Id)
        {
            var findid = await studentService.GetByIDAsync(Id);

            if(findid != null)
            {
                var deleteid = await studentService.DeleteAsync(Id);

                if(deleteid)
                {
                    logger.LogInformation("ID Deleted");
                    return Ok("Student Details Deleted Successfully");
                }
                else
                {
                    return BadRequest("Failed to delete Student Details.");
                }
            }
            return BadRequest("Unable to find id");


        }

        [HttpGet("GetStudentsByCourseNameAsync")]

        public async Task<IActionResult> GetStudentsByCourseNameAsync([FromQuery] string courseName)
        {
            var names = await studentService.GetStudentsByCourseNameAsync(courseName);
            if(names != null)
            {
                return Ok(names);
            }
            else
            {
                return BadRequest("Unable to retrieve students by course name");
            }
        }
    }
}
