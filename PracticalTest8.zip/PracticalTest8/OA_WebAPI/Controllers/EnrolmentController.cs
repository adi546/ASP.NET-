﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RepositoryandServices.Services.CustomServices.EnrolmentService;
using RepositoryandServices.Services.CustomServices.StudentService;
using static OA_Domain.ViewModels.EnrolmentViewModel;
using static OA_Domain.ViewModels.StudentViewModel;

namespace OA_WebAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class EnrolmentController : ControllerBase
    {
        private readonly IEnrolmentService enrolmentService;
        private readonly ILogger<EnrolmentController> logger;

        public EnrolmentController(IEnrolmentService enrolmentService , ILogger<EnrolmentController> logger)
        {
            this.enrolmentService = enrolmentService;
            this.logger = logger;
        }

        [HttpGet("GetAllEnrolmentDetails")]

        public async Task<IActionResult> GetAllEnrolmentDetails()
        {
            var details = await enrolmentService.GetAllAsync();

            if (details != null)
            {
                logger.LogInformation("Successfully Retrieved the details");
                return Ok(details);
            }
            logger.LogWarning("Unable to retrieve details");
            return BadRequest("Details not found");
        }

        [HttpGet("GetEnrolmentDetailsById")]

        public async Task<IActionResult> GetEnrolmentDetailsById(int Id)
        {
            var detailsbyid = await enrolmentService.GetByIDAsync(Id);
            if (detailsbyid != null)
            {
                logger.LogInformation("Successfully Retrieved the details");
                return Ok(detailsbyid);
            }
            logger.LogWarning("Unable to retrieve details");
            return BadRequest("Details not found");
        }

        [HttpPost("AddEnrolmentDetails")]

        public async Task<IActionResult> AddEnrolmentDetails([FromBody] EnrolmentInsertModel enrolmentInsertModel)
        {
            if (ModelState.IsValid)
            {
                var insert = await enrolmentService.InsertAsync(enrolmentInsertModel);

                if (insert)
                {
                    logger.LogInformation("Successfully Inserted");
                    return Ok("Details Inserted Successfully");
                }
                else
                {
                    logger.LogWarning("Unable to insert");
                    return BadRequest("Failed to insert the details");
                }

            }
            return BadRequest("Invalid model state.");
        }

        [HttpPut("UpdateEnrolmentDetails")]

        public async Task<IActionResult> UpdateEnrolmentDetails([FromBody] EnrolmentUpdateModel enrolmentUpdateModel)
        {
            if (ModelState.IsValid)
            {
                var updatestudents = await enrolmentService.GetByIDAsync(enrolmentUpdateModel.EnrolmentId);

                if (updatestudents != null)
                {
                    var update = await enrolmentService.UpdateAsync(enrolmentUpdateModel);

                    if (update)
                    {
                        logger.LogInformation("Details Updated Successfully");
                        return Ok("Details Updated Successfully");
                    }
                    else
                    {
                        logger.LogWarning("Unable to update");
                        return BadRequest("Failed to update details");
                    }
                }

                logger.LogWarning("No Id found");
                return BadRequest("Id does not exist");


            }
            logger.LogWarning("Invalid State");
            return BadRequest("Invalid Model State");
        }

        [HttpDelete("DeleteStudentDetails")]

        public async Task<IActionResult> DeleteStudentDetails(int Id)
        {
            var findid = await enrolmentService.GetByIDAsync(Id);

            if (findid != null)
            {
                var deleteid = await enrolmentService.DeleteAsync(Id);

                if (deleteid)
                {
                    logger.LogInformation("ID Deleted");
                    return Ok("Student Details Deleted Successfully");
                }
                else
                {
                    return BadRequest("Failed to delete Student Details.");
                }
            }
            return BadRequest("Unable to find id");


        }
    }
}
