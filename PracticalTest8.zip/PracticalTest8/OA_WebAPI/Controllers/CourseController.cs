﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RepositoryandServices.Services.CustomServices.CourseService;
using RepositoryandServices.Services.CustomServices.StudentService;
using static Azure.Core.HttpHeader;
using static OA_Domain.ViewModels.CourseViewModel;
using static OA_Domain.ViewModels.StudentViewModel;

namespace OA_WebAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly ICourseService courseService;
        private readonly ILogger<CourseController> logger;

        public CourseController(ICourseService courseService, ILogger<CourseController> logger)
        {
            this.courseService = courseService;
            this.logger = logger;
        }
        [HttpGet("GetAllCourseDetails")]

        public async Task<IActionResult> GetAllCourseDetails()
        {
            var details = await courseService.GetAllAsync();

            if (details != null)
            {
                logger.LogInformation("Successfully Retrieved the details");
                return Ok(details);
            }
            logger.LogWarning("Unable to retrieve details");
            return BadRequest("Details not found");
        }

        [HttpGet("GetCourseDetailsById")]

        public async Task<IActionResult> GetCourseDetailsById(int Id)
        {
            var detailsbyid = await courseService.GetByIDAsync(Id);
            if (detailsbyid != null)
            {
                logger.LogInformation("Successfully Retrieved the details");
                return Ok(detailsbyid);
            }
            logger.LogWarning("Unable to retrieve details");
            return BadRequest("Details not found");
        }

        [HttpPost("AddCourseDetails")]

        public async Task<IActionResult> AddCourseDetails([FromBody] CourseInsertModel courseInsertModel)
        {
            if (ModelState.IsValid)
            {
                var insert = await courseService.InsertAsync(courseInsertModel);

                if (insert)
                {
                    logger.LogInformation("Successfully Inserted");
                    return Ok("Details Inserted Successfully");
                }
                else
                {
                    logger.LogWarning("Unable to insert");
                    return BadRequest("Failed to insert the details");
                }

            }
            return BadRequest("Invalid model state.");
        }

        [HttpPut("UpdateCourseDetails")]

        public async Task<IActionResult> UpdateCourseDetails([FromBody] CourseUpdateModel courseUpdateModel)
        {
            if (ModelState.IsValid)
            {
                var updatestudents = await courseService.GetByIDAsync(courseUpdateModel.CourseId);

                if (updatestudents != null)
                {
                    var update = await courseService.UpdateAsync(courseUpdateModel);

                    if (update)
                    {
                        logger.LogInformation("Details Updated Successfully");
                        return Ok("Details Updated Successfully");
                    }
                    else
                    {
                        logger.LogWarning("Unable to update");
                        return BadRequest("Failed to update details");
                    }

                }

                logger.LogWarning("No Id found");
                return BadRequest("Id does not exist");


            }
            logger.LogWarning("Invalid State");
            return BadRequest("Invalid Model State");


        }

        [HttpDelete("DeleteCourseDetails")]

        public async Task<IActionResult> DeleteCourseDetails(int Id)
        {
            var findid = await courseService.GetByIDAsync(Id);

            if (findid != null)
            {
                var deleteid = await courseService.DeleteAsync(Id);

                if (deleteid)
                {
                    logger.LogInformation("ID Deleted");
                    return Ok("Student Details Deleted Successfully");
                }
                else
                {
                    return BadRequest("Failed to delete Student Details.");
                }
            }
            return BadRequest("Unable to find id");


        }

        [HttpGet("GetMonthlyFeesByCourseAsync")]

        public async Task<IActionResult> GetMonthlyFeesByCourseAsync(int courseId, int year)
        {
            var monthlyfees = await courseService.GetMonthlyFeesByCourseAsync(courseId, year);

            logger.LogInformation("Added Successfully");
            return Ok(monthlyfees);
           

         
        }

    }
}
