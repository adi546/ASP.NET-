﻿using OA_Domain.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace OA_Domain.ViewModels
{
    public class CourseViewModel
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        [JsonIgnore]
        public ICollection<Student> Students { get; set; }
        [JsonIgnore]
        public ICollection<Enrolment> Enrolments { get; set; }

        public class CourseInsertModel
        {
            [Required]
            public string CourseName { get; set; }
        }

        public class CourseUpdateModel : CourseInsertModel
        {
            public int CourseId { get; set; }
        }

    }
}
