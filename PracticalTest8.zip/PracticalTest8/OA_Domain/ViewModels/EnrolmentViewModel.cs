﻿using OA_Domain.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace OA_Domain.ViewModels
{
    public class EnrolmentViewModel
    {

        public int EnrolmentId { get; set; }
        public int StudentId { get; set; }
        [JsonIgnore]
        public Student Student { get; set; }
        public int CourseId { get; set; }
        [JsonIgnore]
        public Course Course { get; set; }
        public DateTime Date { get; set; }
        public int Fees { get; set; }

        public class EnrolmentInsertModel
        {
            [Required]
            public int StudentId { get; set; }
            [Required]
            public int CourseId { get; set; }
            [Required]
            public DateTime Date { get; set; }
            [Required]
            public int Fees { get; set; }
        }

        public class EnrolmentUpdateModel : EnrolmentInsertModel
        {
            public int EnrolmentId { get; set; }
        }


    }
}
