﻿using OA_Domain.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace OA_Domain.ViewModels
{
    public class StudentViewModel
    {
        public int StudentId { get; set; }
        public string Name { get; set; }

        public string Email { get; set; }

        public string PhoneNumber { get; set; }

        public string Gender { get; set; }

        public DateTime DateOfBirth { get; set; }

        public int CourseId { get; set; }
        [JsonIgnore]
        public Course Course { get; set; }
        [JsonIgnore]
        public ICollection<Enrolment> Enrolments { get; set; }

        public class StudentInsertModel
        {
            [Required]
            public string Name { get; set; }
            [Required]
            public string Email { get; set; }
            [Required]
            public string PhoneNumber { get; set; }
            [Required]
            public string Gender { get; set; }
            [Required]
            public DateTime DateOfBirth { get; set; }
            [Required]
            public int CourseId { get; set; }
        }

        public class StudentUpdateModel : StudentInsertModel
        {
            [Required]
            public int StudentId { get; set; }
        }
    }
}
