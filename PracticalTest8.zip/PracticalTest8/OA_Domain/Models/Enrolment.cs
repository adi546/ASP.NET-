﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace OA_Domain.Models
{
    public class Enrolment : BaseEntity
    {
        [Required(ErrorMessage = "StudentId is required.")]
        public int StudentId { get; set; }
     
        public Student Student { get; set; }

        [Required(ErrorMessage = "CourseId is required.")]
        public int CourseId { get; set; }
        [JsonIgnore]
        public Course Course { get; set; }

        [Required(ErrorMessage = "Date is required.")]
        [DataType(DataType.DateTime)]
        public DateTime Date { get; set; }

        [Required(ErrorMessage = "Fees is required.")]
        public int Fees { get; set; }   
    }
}
