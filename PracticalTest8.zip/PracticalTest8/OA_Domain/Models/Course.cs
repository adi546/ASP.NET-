﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace OA_Domain.Models
{
    public class Course : BaseEntity
    {
        [Required(ErrorMessage = "CourseName is required.")]
        public string CourseName { get; set; }
        [JsonIgnore]
        public ICollection<Student> Students { get; set; }
        [JsonIgnore]
        public ICollection<Enrolment> Enrolments { get; set; }
    }
}
